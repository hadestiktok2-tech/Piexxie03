Piexxie03Hub - Neon Test + Shared Troll FX

1) UJI EFEK NEON - PEMAIN TERPILIH
- Pilih pemain pada tab TELEPORT.
- Buka tab Fun lalu tekan UJI EFEK NEON - PEMAIN TERPILIH.
- Highlight dan tulisan KENA NEON tampil selama 4 detik di layar pengguna skrip.
- Ini efek lokal. Pemain lain tidak otomatis melihatnya.

2) NEON SURPRISE - SELECTED PLAYER
- Efek yang terlihat semua pemain memerlukan RemoteEvent dan Script server pendamping di game yang kamu miliki/kelola.
- Pasang Piexxie03Hub_TrollFX_Server.lua sebagai Script di ServerScriptService.
- Atur daftar admin di ADMIN_USER_IDS pada script server.
- Tombol ini tidak dapat membuat efek universal di game publik yang tidak kamu kelola.

Catatan:
Script klien ini dibuat dari Piexxie03Hub_Final_MultiConfig_Delay10.lua dan menambahkan uji efek kosmetik lokal.
